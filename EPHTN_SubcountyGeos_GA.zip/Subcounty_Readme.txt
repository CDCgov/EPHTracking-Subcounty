This .zip file contains materials needed to summarize census tract-level data to the Centers for Disease Control and Prevention's (CDC) Environmental Public Health Tracking Program's (Tracking Program) sub-county geographies. These geographies are currently available to have a minimum population of 5,000 or 20,000 with some exceptions (e.g., areas with zero population or counties not able to combine with neighboring counties to meet the population minimum). Materials included are:
	1. ephtn_subcounty_readme.txt (this file)
	2. gz_2010_<state fips>_140_00_500k (Generalized (gz) Cartographic Boundaries Files Census tract shapefiles)
	3. subcounty_5k_STFIPS_<state_FIPS> (5,000 person minimum population shapefiles)
	4. subcounty_20k_STFIPS_<state_FIPS> (20,000 person minimum population shapefiles)
	5. <state_name>_Crosswalk.xlsx (Crosswalk file)
File naming convention:
	State name and FIPS code will correspond to the state the files contain data for.
Document descriptions:
•	Census Tract Shapefiles
o	file name: gz_2010_<state fips>_140_00_500k
o	Generalized census tracts from the 2010 Decennial Census, downloaded from the US Census Bureau.
•	5,000=person minimum population shapefiles
o	file name: subcounty_5k_STFIPS_<state_FIPS>
o	5,000-person minimum population geographies created by the Tracking Program. These shapefiles contain the total aggregated populations and current names assigned by the Tracking Program.
•	20,000-person minimum population shapefiles
o	file name: subcounty_20k_STFIPS_<state_FIPS>
o	20,000-person minimum population geographies created by the Tracking Program. These shapefiles contain the total aggregated populations and current names assigned by the Tracking Program.
•	Crosswalk file
o	file name: <state_name>_Crosswalk_<date>.xlsx
o	Contains information for all census tracts within the state as of the 2010 Decennial Census plus known applicable recodes for census tracts that have received a new FIPS. Other columns in the crosswalk include:
	_5k_Geographic_ID: The geographic ID assigned at the 5,000-person minimum population aggregation level.
	_20k_Geographic_ID: The geographic ID assigned at the 20,000-person minimum population aggregation level.
	ZP_flag: A flag variable (0 = off, 1 = on) to designate census tracts with zero population as of the 2010 Decennial Census.
	Other_flag: A flag variable (0 = off, 1 = on) to designate census tracts not mapped by the Tracking Program. These are typically large water bodies along coastal borders.
	County_flag_5k: A flag variable (0 = off, 1 = on) to designate census tracts within a county that have a population under 5,000 that are not able to be combined with a neighboring county also under 5,000 population.
	County_flag_20k: A flag variable (0 = off, 1 = on) to designate census tracts within a county that have a population under 20,000 that are not able to be combined with a neighboring county also under 20,000 population.
	CombinedCounty_5k: A flag variable (0 = off, 1 = on) to designate census tracts within a county that have a population under 5,000 that get combined with a neighboring county also under 5,000 population.
	CombinedCounty_20k: A flag variable (0 = off, 1 = on) to designate census tracts within a county that have a population under 20,000 that get combined with a neighboring county also under 20,000 population.
To use:
	By using standard 11-digit (State + County + Census Tract) FIPS codes, census tract-level data can be linked to the provided crosswalk. Data can then be summarized to the desired geography level by using the unique identifiers in the _5k_Geographic_ID or _20k_Geographic_ID columns. After summarization, data can then be linked to the provided shapefiles for display in GIS softwares.
The Tracking Program has developed a standard naming convention for its sub-county geographies. These naming conventions are used to provide context and help geographically orient the user when viewing data on the Tracking Portal. The naming convention for each geography type is:
	Sub-county: 		County name, State abbreviation – Truncated FIPS code* – 5K/20K
	County: 		County name, State abbreviation
	Combined county:	State abbreviation– Truncated FIPS code*– Combined Counties
	Zero population tracts:	County name, State abbreviation – Truncated FIPS Code* – Zero Pop
	*FIPS code with state + county code segments removed
